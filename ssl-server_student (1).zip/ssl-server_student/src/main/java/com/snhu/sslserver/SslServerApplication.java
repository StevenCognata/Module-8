package com.snhu.sslserver;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@SpringBootApplication
public class SslServerApplication {
	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController{
    public static String calculateHash(String name) throws NoSuchAlgorithmException {
        MessageDigest message = MessageDigest.getInstance("SHA-256");
        byte[] fileHash = message.digest(name.getBytes(StandardCharsets.UTF_8));
        BigInteger num =  new BigInteger(1, fileHash);
        StringBuilder stringHex = new StringBuilder(num.toString(16));
        while (stringHex.length() < 32) {
            stringHex.insert(0, '0');
        }
        return stringHex.toString();
    }

    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
    	String data = "Hello World Check Sum";
        String fileHash = calculateHash(data);
        return  "<p>data:" + data +" <br> Name of Cipher Algorithm Used : SHA-256 " + " : "+fileHash;
    }
}
